-----Это фйл фабрика коробок
box= {}
--тело класса
function box:new(x, y)

    -- свойства
    local obj= {}
        obj.body = love.physics.newBody(world, x,y, "dynamic")
        obj.shape = love.physics.newRectangleShape(0, 0, 96, 96)
        obj.fixture = love.physics.newFixture(obj.body, obj.shape, 5)
         obj.prig=obj.fixture:setRestitution(0.3) -- устанавливаем "отскок" (упругость) героя max=1
         obj.trenie=obj.fixture:setFriction( 0,6 )

    -- метод
    function box:gra(i)--отрисовка коробок
   if i==nil then i=1 
  elseif i==0 then i=1 end
   love.graphics.draw(textur.boximg,textur.box[i],self.body:getX( )-96/2,self.body:getY( )-96/2)
   end
    --чистая магия!
    setmetatable(obj, self)
    self.__index = self; return obj
end
--создаем экземпляр класса
--vasya = Person:new(x,y)--Кординаты появления

mod={}
--тело класса
function mod:new(fName, lName)

    -- свойства
    local obj= {}
       obj.body = love.physics.newBody(world, x,y, "dynamic")
        obj.shape = love.physics.newRectangleShape(0, 0, 96, 96)
        obj.fixture = love.physics.newFixture(obj.body, obj.shape, 5)

    -- метод
    function obj:getName()
        return self.firstName 
    end

    --чистая магия!
    setmetatable(obj, self)
    self.__index = self; return obj
end